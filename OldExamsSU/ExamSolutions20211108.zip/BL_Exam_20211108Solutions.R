setwd('~/Dropbox/Teaching/BayesLearning/Hidden/Exam/20211108/')
rm(list = ls())

# PROBLEM 1

# 1a)

load("Problem1.RData")

logPost<- function(theta, x){
  return(logLik = sum(log(2/(sqrt(3)*pi)) -2*log(1 + (x-theta)^2/3))) + dnorm(theta, mean = 0, sd = 10, log = T)
}

thetaGrid = seq(2,6, by = 0.01)
logPostGrid = rep(0,length(thetaGrid))
count = 0
for (theta in thetaGrid){
  count = count + 1
  logPostGrid[count] = logPost(theta,x) 
}

DeltaGrid = thetaGrid[2] - thetaGrid[1]
posterior = exp(logPostGrid)/(DeltaGrid*sum(exp(logPostGrid)))
# check: sum(posterior*DeltaGrid)
plot(thetaGrid, posterior, type = "l", ylab = "posterior density", xlab = "theta")

# 1b)

# The problem does no specify what type of interval, so we will do an equal tail 
c( max(thetaGrid[cumsum(posterior*DeltaGrid) <= 0.025]), min(thetaGrid[cumsum(posterior*DeltaGrid) >= 0.975]))

# 1c)
# This can be done matematically or numerically using optim. We will do the optim-version here.
initVal <- mean(x)
OptimResults<-optim(initVal, logPost, gr=NULL, x,
                    method=c("BFGS"), control=list(fnscale=-1), hessian=TRUE)
postMode = OptimResults$par
postCov = -solve(OptimResults$hessian) # inv(J) - Approx posterior covariance matrix

lines(thetaGrid, dnorm(thetaGrid, mean = postMode, sd = sqrt(postCov)), col = "red")

# Credible interval from normal approximation:
c(postMode - 1.96*sqrt(postCov), postMode + 1.96*sqrt(postCov))

# 1d)
# This can be done using numerical integration or Monte Carlo. 
# Since we only need an approximate answer, we can use Monte Carlo based on the normal approximation from 1c)
thetaDraws = rnorm(n = 100000, mean = postMode, sd = sqrt(postCov))
mean((thetaDraws-3)^2)

# PROBLEM 2
source("BayesLinReg.R")
load("Salaries.RData")

# 2a)
# Linear loss -> Posterior median is the Bayes estimator
y = log(Salaries$salary)
X = as.matrix(cbind(1,Salaries[,3:4]))
mu_0 = as.matrix(c(log(10000),0,0))
Omega_0 = diag(3)
v_0 = 10
sigma2_0 = 1
nIter = 10000
PostDraws  <- BayesLinReg(y, X, mu_0, Omega_0, v_0, sigma2_0, nIter)
betaDraws = PostDraws$betaSample
sigma2Draws = PostDraws$sigma2Sample
c(median(betaDraws[,1]), median(betaDraws[,2]), median(betaDraws[,3]))

# 2b)
# There are three ways to solve this:
# 1. one can take the brute force approach and compute the HPD from the simulations
# in 2a) without using any other knowledge about the posterior.
# 2. one can use the result that the marginal posterior of the regression coefficients are student-t distributed. Since the 
# student-t is a symmetric distribution, HPD intervals are the same as equal-tail intervals.
# 3. The HPD (equal tail interval) can be obtained analytically using properties of the student-t distribution.
# We will take the second  approach here.

c(quantile(betaDraws[,3], 0.025),quantile(betaDraws[,3], 0.975))

# Posterior probability that beta2 is in the interval (-0.0113541300, -0.0004016719) is 0.95. 

#2c)
xTilde = c(1,12,18)
yPreds = rep(0,nIter)
for (i in 1:nIter){
  logy = betaDraws[i,]%*%xTilde + rnorm(1, mean = 0, sd  = sqrt(sigma2Draws[i]))
  yPreds[i] = exp(logy)
}
hist(yPreds, 50, xlab = "Predicted salary")

# 2d) 
# All! Since we have a conjugate prior the marginal posterior and the predictive distributions are both student-t distributions, that are available in analytical form. 
# The student-t is symmetric so the mean = median.


# Problem 4
y = c(190,193,192,197,188)
mean(y)

# 4b
1 - pnorm(230, mean = 192, sd=10.95)^365

# 4c
cGrid = seq(20,27, by = 0.01)
count = 0
U = rep(length(cGrid)) 
for (c in cGrid){
  count = count + 1
  U[count] = c*pnorm(10*c, mean = 192, sd=10.95)^365 + (100+c)*(1-pnorm(10*c, mean = 192, sd=10.95)^365)
}
plot(cGrid, U, type = "l")
cOpt = cGrid[which.min(U)]



maxYear = rep(0,1000,1)
for (i in 1:1000){
  maxYear[i] = max(rnorm(365, 192, 10.95))
}
sum(maxYear>230)/1000
